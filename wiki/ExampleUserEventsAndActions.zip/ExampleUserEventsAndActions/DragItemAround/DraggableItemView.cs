//
//  
//  DragItemAround
//  DraggableItemView.cs
//
//  Created by Todd Schavey on 3/3/07.
//  Copyright 2007
//
//  Based upon Apple's Cocoa Example found at:
//  http://developer.apple.com/samplecode/DragItemAround/listing5.html
//

using System;
using Cocoa;

namespace DragItemAround
{   
    /// <summary>
    /// A custom view that draws a rectangular item for the user to
    /// drag around via the mouse or the keyboard. This name must 
    /// match the name of the custome NSView subclass define in the
    /// in the .nib
    /// </summary>    
    [Register ("DraggableItemView")]
    public class DraggableItemView : View 
    {
        
        #region Attributes
               
        private Point mLocation;
        private Color mItemColor;
        private Color mBackgroundColor;
		
        #endregion
        
        #region Constructors
        
        public DraggableItemView ()
        {
            SetItemPropertiesToDefault( null );
        }
        
        [Export ("initWithFrame:")]
		public DraggableItemView (Rect frame) 
            : base (frame)
        {
            SetItemPropertiesToDefault( null );
        }
        
		public DraggableItemView (IntPtr native_object) 
            : base (native_object)
        {
            SetItemPropertiesToDefault( null );
        }
        
        #endregion
        
        #region Properties
       
        /// <summary>
        /// Get/sets the current location of the item in the view.
        /// </summary>        
        public Point Location
        {
            get
            { 
                return mLocation;
            }
            set
            {
                /// Determine if the point actually changed...
                ///
                if( mLocation != value )
                {                   
                    /// reassign the rect
                    ///
                    mLocation = value;
                    
                    /// Display the new rect
                    NeedsDisplay( CalculatedItemBounds );
                    
                    /// Invalidate the cursor rects
                    ///
                    /// TODO: Needs to get the CocoaSharp library to support this yet...
                    //Window.InvalidateCursorRectsForView( this ); 
                }
            }
        }
        
        /// <summary>
        /// Get/sets the current color of the item in the view.
        /// </summary>
        public Color ItemColor
        {
            get{ return mItemColor; }
            set{ mItemColor = value; }
        }
        
        /// <summary>
        /// Get/sets the backgound color of the view.
        /// </summary>
        public Color BackgroundColor
        {
            get{ return mBackgroundColor; }
            set
            { 
                mBackgroundColor = value;
                NeedsDisplay( CalculatedItemBounds );
            }
        }
        
        /// <summary>
        /// Determines if the view is opaque.
        /// </summary>
        /// <remarks>
        /// From the Apple article = "The display... methods must find an opaque
        /// background behind the view requires displaying and begin drawing from
        /// there forward. The display... methods search up the view hierarchy to
        /// locate the first view that responds YES to an isOpaque message, bringing
        /// the invalidated rectangles along.
        ///
        /// If a view instance can guarantee that it will fill all the pixels within
        /// its bounds using opaque colors, it should implement the method isOpaque,
        /// returning YES. The NSView implementation of isOpaque returns NO. Subclasses
        /// should override this method to return YES if all pixels within the view's
        /// content will be drawn opaquely.
        /// </remarks>
        public override bool IsOpaque()
        {
            return BackgroundColor.AlphaComponent >= 1.0 ? true : false;
        }
        
        /// <summary>
        /// Calculates the new item bound based upon the current locaiton.
        /// </summary> 
        public Rect CalculatedItemBounds
        {
            get
            {
                Rect lCalculatedRect;
                
                /// Calculate the bounds of the draggable item relative to the location.
                ///
                lCalculatedRect.Origin = Location;
                
                /// The example assumes that the width and height are fixed values.
                ///
                lCalculatedRect.Size.Width = 60.0F;
                lCalculatedRect.Size.Height = 20.0F;
                
                return lCalculatedRect;
            }
        }
        
        
        #endregion
        
        #region Methods
        
        /// <summary>
        /// Indicates to the window that we want to listen to keyboard events.
        /// </summary>
        public override bool AcceptsFirstResponder()
        {
            return true;
        }
        
        /// <summary>
        /// Offset the current position of the item by X and Y.
        /// </summary>
        /// <param name="aX">The amount of horizontal offset.</param>
        /// <param name="aY">The amount of veritical offset.</param>
        protected void OffsetLocation( float aX, float aY )
        {
            /// Tell the display to redraw  the old display.
            ///
            NeedsDisplay( CalculatedItemBounds );
            
            /// Since the offset can be geneated by both mouse moves
            /// and moveUp, moveDown, etc...actions, we'll invert the
            /// deltaY amount based on if the view is flipped or not.
            if( IsFlipped )
            {
                aY *= -1;
            }
            
            
            Point lNewLocation = Location; /// I have to create a copy because Point is a struct.
            lNewLocation.X += aX; 
            lNewLocation.Y += aY;
            Location = lNewLocation;
        }
        
        /// <summary>
        /// Determines if the point is within the item.
        /// </summary>
        /// <param name="aPoint">The point in quesiton.</param>
        /// <return>True if the point is found in the item bounds.</return>
        protected bool IsPointInItem( Point aPoint )
        {
            if( CalculatedItemBounds.Contains( aPoint ) )
            {
                return true;
            }
            return false;
        }
        
        

        #endregion

        #region Event Handlers
        
        /// <summary>
        /// Automatically called by the Cocoa environment when the view's content
        /// area needs to be redrawn.
        /// </summary>
        /// <param name="aRect">The region on the screen that the view owns.</param>
        public override void OnDrawRect (Rect aRect) 
        {		
                /// Draw a white canvas with a block border...
                ///
                Color.White.Set();
                BezierPath.FillRect( Bounds );
                Color.Black.Set();
                BezierPath.StrokeRect( Bounds );
                
                /// Draw a our little box with black outline..
                ///
                ItemColor.Set();
                BezierPath.FillRect( CalculatedItemBounds );
        }
        
        /// <summary>
        /// Automatically called by the Cocoa environment when the mouse was
        /// clicked down within the view. AcceptsFirstResponder must be overriden
        /// and return true for the Cocoa environment to trap the mouse event.
        /// </summary>
        /// <param name="aEvent">Class defining metadata information about the mouse click.</param>
        public override void OnMouseDown( Event aEvent )
        {
            /// TODO: We need to get the ConvertPointFromView working
            ///       in order for the event's location coordinates
            ///       to make sense.
            ///
            Point lClickLocation = aEvent.LocationInWindow; //ConvertPointFromView( aEvent.LocationInWindow, null );
            
            Console.WriteLine( "Mouse down at x:{0}, y:{1}", lClickLocation.X, lClickLocation.Y );
            
            /// Did the click occur in the draggable item?
            ///
            if( IsPointInItem( lClickLocation ) )
            {
                Console.WriteLine( "HIT" );
                
                /// We're dragging, so let's set thte curor to the closed hand.
                ///
                Cursor.ClosedHandCursor.Push();
                
                Point lNewDragPoint;
                    
                /// The tight event loop pattern doesn't require the use of any
                /// variables, so we'll use a local variable lLastDragLocation instead.
                /// Save the starting location as the first relative point
                ///
                Point lLastDragLocation = lClickLocation;
                
                bool lLoop = true;
                
                while( lLoop )
                {
                    /// TODO: This part is waiting for the above ConvertPointFromView to
                    ///       start working...
                    ///
                    lLoop = false;
                }
            }
            
        }
        
        
        public override void OnKeyDown( Event aEvent )
        {                               
            if( aEvent.CharactersIgnoringModifiers == "r" )
            {
                SetItemPropertiesToDefault( this );
                return;
            }
            
            base.OnKeyDown( aEvent );
        }
        
        
        public override void OnKeyDownArrowUp()
        {
            OffsetLocation( 0.0F, 10.0F );
            Window.InvalidateCursorRectsForView( this ); 
        }
        
        public override void OnKeyDownArrowDown()
        {
            OffsetLocation( 0.0F, -10.0F );
            Window.InvalidateCursorRectsForView( this );
        }
        
        public override void OnKeyDownArrowLeft()
        {
            OffsetLocation( -10.0F, 0.0F );
            Window.InvalidateCursorRectsForView( this );
        }
        
        public override void OnKeyDownArrowRight()
        {
            OffsetLocation( 10.0F, 0.0F );
            Window.InvalidateCursorRectsForView( this );
        }
        
        [Export ("setItemPropertiesToDefault:")]
        public void SetItemPropertiesToDefault( Cocoa.Object sender )
        {
            Location = new Point( 0, 0 );
            ItemColor = Color.Red;
            BackgroundColor = Color.White;
        }
        
        [Export("changeColor:")]
        public void ChangeColor( Cocoa.Object aSender )
        {
            /// TODO: This method still needs to be implemented...but
            ///       currently clicking on the ColorWell in the window
            ///       crashes the entire application.
            Console.WriteLine( "Change Color...." );
        }
                
        
        #endregion
                
	}
}
