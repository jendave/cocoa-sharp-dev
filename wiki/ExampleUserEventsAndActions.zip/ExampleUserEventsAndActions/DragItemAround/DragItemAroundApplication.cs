//
//  
//  DragItemAround
//  DragItemAroundApplication.cs
//
//  Created by Todd Schavey on 3/3/07.
//  Copyright 2007
//
//  Based upon Apple's Cocoa Example found at:
//  http://developer.apple.com/samplecode/DragItemAround/listing5.html
//

using System;
using System.Collections.Generic;
using System.Text;
using Cocoa;

namespace DragItemAround
{
	class DragItemAroundApplication
	{
        static void Main(string[] args) 
        {
            DragItemAroundApplication lMain = new DragItemAroundApplication();
            lMain.Run();
        }

        public void Run() 
        {
            Application.Init();
            Application.LoadNib("Main.nib");
            Application.Run();
        }
    }
}
