//
//  
//  DragItemAround
//  ApplicationController.cs
//
//  Created by Todd Schavey on 3/3/07.
//  Copyright 2007
//
//  Based upon Apple's Cocoa Example found at:
//  http://developer.apple.com/samplecode/DragItemAround/listing5.html
//

using System;
using System.Collections.Generic;
using System.Text;
using Cocoa;

namespace DragItemAround
{
    [Register("ApplicationController")]
	class ApplicationController : Cocoa.Object 
    {
        /// <summary>
        /// Reference to the main window. This name must match the
        /// name of the outlet found in the .nib
        /// </summary>
        [Connect]
        public Cocoa.Window mainWindow;
        
        /// <summary>
        /// Reference to the ColorWell control found on the window in the .nib.
        /// This name must match the name of the outlet found in the .nib
        /// </summary>
        [Connect]
        public Cocoa.ColorWell colorWell;
        
        /// <summary>
        /// Standard constructor for the ApplicationController.
        /// </summary>
		public ApplicationController(System.IntPtr a)
            : base(a)
        {
        }
        
        /// <summary>
        /// Equivelanet to the a WinForm OnLoad event handler.
        /// </summary>
        [Export("applicationWillFinishLaunching:")]
        public void FinishLoading(Cocoa.Notification notification)
        {
            /// Simply for debuggin' purpose...
            ///
            Console.WriteLine("Form Loaded");
        }
                
	}
}