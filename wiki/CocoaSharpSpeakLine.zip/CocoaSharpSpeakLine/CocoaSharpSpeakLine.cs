//
//  
//  CocoaSharpSpeakLine
//
//  Created by Todd Schavey on 2/23/07.
//  Copyright 2007 __MyCompanyName__. All rights reserved.
//
//

using System;
using System.Collections.Generic;
using System.Text;
using Cocoa;

namespace CocoaSharpSpeakLine
{
	class CocoaSharpSpeakLine
	{
        static void Main(string[] args) 
        {
            CocoaSharpSpeakLine main = new CocoaSharpSpeakLine();
            main.Run();
        }

        public void Run() 
        {
            Application.Init();
            Application.LoadNib("Main.nib");
            Application.Run();
        }
    }
}
