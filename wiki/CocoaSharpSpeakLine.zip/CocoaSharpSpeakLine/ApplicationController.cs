//
//  
//  CocoaSharpSpeakLine
//
//  Created by Todd Schavey on 2/23/07.
//  Copyright 2007 __MyCompanyName__. All rights reserved.
//
//

using System;
using System.Collections.Generic;
using System.Text;
using Cocoa;

namespace CocoaSharpSpeakLine
{
    [Register("ApplicationController")]
	class ApplicationController : Cocoa.Object
    {
        /// Gui member variables the must be [Connect]ed
        ///
        [Connect]
        public Cocoa.Window mainWindow;
        
        [Connect]
        public Cocoa.TextField textField;

        //[Connect]
        //protected ColorWell colorWell;
                
        /// Geneal member variables
        ///
        protected Cocoa.SpeechSynthesizer synth = new SpeechSynthesizer();

        
        /// Default constructor
        ///
		public ApplicationController(System.IntPtr a)
            : base(a)
        {
                synth.EnableDelegate = true;
                synth.DidFinishSpeaking += new SpeechSynthesizer.DidFinishSpeakingEventHandler( OnDidFinishSpeakingEventHandler );
        }
        
        
        /// FinishLoading function is called after the window and all of its
        /// gui componets have completed loading.
        ///
        [Export("applicationWillFinishLaunching:")]
        public void FinishLoading(Cocoa.Notification notification)
        {
            Console.WriteLine("Form Loaded");
        }
        
        /// Called when the SayIt button is clicked. Remember that this button
        /// must be connected 'from' the Button 'to' the AppController instance
        /// in the .nib.
        ///
        [Export("sayIt:")]
        public void OnClick_SayItButton( Cocoa.Object sender )
        {
            if( textField.Value.Length == 0 )
            {
                return;
            }
            synth.StartSpeaking( textField.Value );      
            Console.WriteLine( "[{0}] - Have started to say: '{1}'", this, textField.Value );
        }
        
        /// Called when the Stop button is clicked. Remember that this button
        /// must be connected 'from' the Button 'to' the AppController instance
        /// in the .nib.
        ///
        [Export("stopIt:")]
        public void OnClick_StopButton( Cocoa.Object sender )
        {
            Console.WriteLine( "[{0}] - stopping", this );
            synth.StopSpeaking();
        }
        
        
        private void OnDidFinishSpeakingEventHandler( SpeechSynthesizer aSender, bool aFinishedSpeaking )
        {
            Console.WriteLine( "[{0}] - finished speaking...", this );
        }
	}
}